{
  config,
  lib,
  pkgs,
  ...
}: let
  inherit (lib.meta) getExe;

  cfg = config.services.zapret2;
  settings = import ./settings.nix {inherit config;};
in {
  system.build.zapretStrategyTest = pkgs.runCommand "zapret-strategy-test" {nativeBuildInputs = [pkgs.util-linux];} ''
    unshare --user --map-current-user --net --keep-caps \
      setpriv --bounding-set=-setuid,-setgid --inh-caps=-setuid,-setgid --ambient-caps=-setuid,-setgid \
      ${getExe cfg.package} --intercept=0 \
      --lua-init=@${cfg.package}/share/zapret2/lua/zapret-lib.lua \
      --lua-init=@${cfg.package}/share/zapret2/lua/zapret-antidpi.lua \
      --lua-init=@${settings.strategy} \
      --lua-init=@${./strategy-test.lua}
    touch "$out"
  '';
}
