{
  config,
  lib,
  ...
}: let
  inherit (builtins) listToAttrs;
  inherit (lib.attrsets) concatMapAttrs;

  settings = import ./settings.nix {inherit config;};

  fakeTtlFallback = toString 3;
  fakeAutoTtlIpv4 = "-1,3-20";
  fakeAutoTtlIpv6 = "-1,3-20";
  fakeTtlOptions = {
    ipv4 = "ip_ttl=${fakeTtlFallback}:ip_autottl=${fakeAutoTtlIpv4}";
    ipv6 = "ip6_ttl=${fakeTtlFallback}:ip6_autottl=${fakeAutoTtlIpv6}";
  };
  quicFailurePacketThreshold = toString 6;

  mkProfiles = protocol: parameters:
    listToAttrs (map (family: let
      name = "${protocol}-${family}";
    in {
      inherit name;
      value = {
        hosts.autodetect = {
          enable = true;
          file = "${settings.autoHostlistDir}/${name}.txt";
        };
        parameters = ["--filter-l3=${family}"] ++ parameters fakeTtlOptions.${family};
      };
    }) ["ipv4" "ipv6"]);
in {
  services.zapret2.profiles = concatMapAttrs mkProfiles {
    http = ttlOptions: [
      "--filter-tcp=80"
      "--payload=http_req"
      "--lua-desync=fake:blob=fake_default_http:tcp_md5:fwmark=${settings.splitCompletedMark}:${ttlOptions}"
    ];
    https = ttlOptions: [
      "--filter-tcp=443"
      "--payload=tls_client_hello"
      "--lua-desync=connection_fake:tcp_md5:fwmark=${settings.splitCompletedMark}:${ttlOptions}"
    ];
    quic = ttlOptions: [
      "--filter-udp=443"
      "--hostlist-auto-udp-out=${quicFailurePacketThreshold}"
      "--payload=quic_initial"
      "--lua-desync=fake:blob=fake_default_quic:${ttlOptions}"
    ];
  };
}
